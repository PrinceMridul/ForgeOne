import { AgentRegistry } from './agent-registry';
import { SharedContext } from './context';
import { ExecutionPipeline } from './pipeline';
import type { WorkflowRun, ExecutionEvent, GeneratedArtifact } from './types';

export class RunManager {
  private static instance: RunManager;
  private readonly runs: Map<string, WorkflowRun> = new Map();
  private readonly contexts: Map<string, SharedContext> = new Map();
  private readonly events: Map<string, ExecutionEvent[]> = new Map();
  private readonly artifacts: Map<string, GeneratedArtifact[]> = new Map();
  private readonly registry: AgentRegistry;
  private readonly pipeline: ExecutionPipeline;

  private constructor() {
    this.registry = new AgentRegistry();
    this.pipeline = new ExecutionPipeline(this.registry);
    this.seedMockRun();
  }

  public static getInstance(): RunManager {
    if (!RunManager.instance) {
      RunManager.instance = new RunManager();
    }
    return RunManager.instance;
  }

  public async startRun(projectId: string, title: string, description: string): Promise<WorkflowRun> {
    const runId = crypto.randomUUID();
    const now = new Date().toISOString();

    const run: WorkflowRun = {
      id: runId,
      projectId,
      title,
      description,
      status: 'PENDING',
      currentAgent: 'ORCHESTRATOR',
      stepProgress: 0,
      totalSteps: 8,
      completedSteps: 0,
      error: null,
      startedAt: now,
      completedAt: null,
      createdAt: now,
    };

    const context = new SharedContext(runId, projectId, title, description);
    this.runs.set(runId, run);
    this.contexts.set(runId, context);
    this.events.set(runId, []);
    this.artifacts.set(runId, []);

    // Execute pipeline asynchronously
    void this.executeRun(run, context);

    return run;
  }

  private async executeRun(run: WorkflowRun, context: SharedContext): Promise<void> {
    try {
      await this.pipeline.executePipeline(
        run,
        context,
        (event) => {
          const runEvents = this.events.get(run.id) ?? [];
          runEvents.push(event);
          this.events.set(run.id, runEvents);
        },
        (artifact) => {
          const runArtifacts = this.artifacts.get(run.id) ?? [];
          runArtifacts.push(artifact);
          this.artifacts.set(run.id, runArtifacts);
        },
        (currentAgent, stepProgress, completedSteps) => {
          run.currentAgent = currentAgent;
          run.stepProgress = stepProgress;
          run.completedSteps = completedSteps;
        },
      );

      run.status = 'COMPLETED';
      run.completedAt = new Date().toISOString();
      run.stepProgress = 100;
    } catch (err) {
      run.status = 'FAILED';
      run.error = err instanceof Error ? err.message : 'Pipeline execution failed';
      run.completedAt = new Date().toISOString();
    }
  }

  public listRuns(): WorkflowRun[] {
    return Array.from(this.runs.values());
  }

  public getRun(runId: string): WorkflowRun | undefined {
    return this.runs.get(runId);
  }

  public getRunEvents(runId: string): ExecutionEvent[] {
    return this.events.get(runId) ?? [];
  }

  public getRunArtifacts(runId: string): GeneratedArtifact[] {
    return this.artifacts.get(runId) ?? [];
  }

  public getRunArtifactContent(runId: string, artifactId: string): GeneratedArtifact | undefined {
    const runArtifacts = this.artifacts.get(runId) ?? [];
    return runArtifacts.find((a) => a.id === artifactId || a.filename === artifactId);
  }

  private seedMockRun(): void {
    const mockId = 'f1eebc99-9c0b-4ef8-bb6d-6bb9bd380a99';
    const projectId = 'a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11';
    const now = new Date().toISOString();

    const mockRun: WorkflowRun = {
      id: mockId,
      projectId,
      title: 'ForgeOne Autonomous Execution',
      description: 'End-to-end autonomous engineering pipeline execution',
      status: 'COMPLETED',
      currentAgent: 'DOCUMENTATION',
      stepProgress: 100,
      totalSteps: 8,
      completedSteps: 8,
      error: null,
      startedAt: now,
      completedAt: now,
      createdAt: now,
    };

    const context = new SharedContext(mockId, projectId, mockRun.title, mockRun.description);
    this.runs.set(mockId, mockRun);
    this.contexts.set(mockId, context);
    this.events.set(mockId, []);
    this.artifacts.set(mockId, []);
  }
}
