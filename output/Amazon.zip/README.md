# ProductionReady Ecommerce Called

Build a production-ready ecommerce platform called ShopSphere.

Requirements:

- Authentication
- Products
- Categories
- Search
- Reviews
- Shopping Cart
- Checkout
- Payments
- Inventory
- Orders
- Coupons
- Wishlists
- Recommendations

Seller Dashboard:
- Products
- Orders
- Inventory
- Analytics

Tech:
- PostgreSQL
- Stripe
- Docker
- Redis
- CI/CD

## Capabilities

- **Authentication & tenancy** — Session-based auth with per-tenant row scoping
- **Billing & subscriptions** — Stripe webhooks reconciled against a local subscription ledger
- **Search** — Postgres full-text search with a GIN index and ranked results
- **Analytics & reporting** — Pre-aggregated rollup tables refreshed on write
- **AI features** — Embedding pipeline backed by a vector index for semantic recall

## API

| Route | Methods | Description |
|---|---|---|
| `/health` | `GET` | Liveness probe |
| `/api/products` | `GET` `POST` `DELETE` | Product resource |
| `/api/orders` | `GET` `POST` `DELETE` | Order resource |
| `/api/dashboards` | `GET` `POST` `DELETE` | Dashboard resource |
| `/api/events` | `GET` `POST` `DELETE` | Event resource |

## Data model

- **products** — name, priceCents, sku
- **orders** — status, totalCents, placedAt
- **dashboards** — name, layout
- **events** — kind, payload, occurredAt

## Quick start

```bash
npm install
npm run dev
```

Then:

```bash
curl http://localhost:4000/health
```
