-- Schema for production-ready-ecommerce-called
-- Generated from the project blueprint.

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  priceCents integer,
  sku text,
  created_at timestamptz not null default now()
);

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  status text,
  totalCents integer,
  placedAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists dashboards (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  layout text,
  created_at timestamptz not null default now()
);

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  kind text,
  payload text,
  occurredAt timestamptz,
  created_at timestamptz not null default now()
);

-- Full-text search over the primary text column of each resource.
create index if not exists products_search_idx on products using gin (to_tsvector('english', coalesce(name::text, '')));
create index if not exists orders_search_idx on orders using gin (to_tsvector('english', coalesce(status::text, '')));
create index if not exists dashboards_search_idx on dashboards using gin (to_tsvector('english', coalesce(name::text, '')));
create index if not exists events_search_idx on events using gin (to_tsvector('english', coalesce(kind::text, '')));
