import Fastify from 'fastify';
import { productsRoutes } from './routes/products';
import { ordersRoutes } from './routes/orders';
import { dashboardsRoutes } from './routes/dashboards';
import { eventsRoutes } from './routes/events';

const app = Fastify({ logger: true });

async function main() {
  app.get('/health', async () => ({
    status: 'ok',
    service: 'production-ready-ecommerce-called',
    timestamp: new Date().toISOString(),
  }));

  await app.register(productsRoutes, { prefix: '/api/products' });
  await app.register(ordersRoutes, { prefix: '/api/orders' });
  await app.register(dashboardsRoutes, { prefix: '/api/dashboards' });
  await app.register(eventsRoutes, { prefix: '/api/events' });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen({ port, host: '0.0.0.0' });
  app.log.info(`production-ready-ecommerce-called listening on http://localhost:${port}`);
}

main().catch((err) => {
  app.log.error(err);
  process.exit(1);
});
