import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { ordersRoutes } from '../src/routes/orders';

describe('orders routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(ordersRoutes, { prefix: '/orders' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/orders' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/orders', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a order', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/orders',
      payload: {
      status: 'example',
      totalCents: 1,
      placedAt: new Date().toISOString(),
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/orders/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
