import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { productsRoutes } from '../src/routes/products';

describe('products routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(productsRoutes, { prefix: '/products' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/products' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/products', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a product', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/products',
      payload: {
      name: 'example',
      priceCents: 1,
      sku: 'example',
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/products/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
