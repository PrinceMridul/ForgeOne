# Online Chess Called

Build an online chess platform called GrandMaster.

Features:

- User accounts
- Live multiplayer
- Chess engine integration
- Matchmaking
- ELO rating
- Puzzles
- Lessons
- Opening explorer
- Analysis board
- Game replay
- Friends
- Clubs
- Leaderboards
- Tournaments
- Spectator mode
- Anti-cheat

Admin:
- Moderation
- Fair play
- Tournament management

Tech:
- WebSockets
- PostgreSQL
- Redis
- Docker
- Production-ready README

## Capabilities

- **Realtime collaboration** — WebSocket gateway with per-room fan-out and presence heartbeats
- **Authentication & tenancy** — Session-based auth with per-tenant row scoping
- **AI features** — Embedding pipeline backed by a vector index for semantic recall

## API

| Route | Methods | Description |
|---|---|---|
| `/health` | `GET` | Liveness probe |
| `/api/boards` | `GET` `POST` `DELETE` | Board resource |
| `/api/users` | `GET` `POST` `DELETE` | User resource |

## Data model

- **boards** — name, columnOrder
- **users** — email, displayName, avatarUrl

## Quick start

```bash
npm install
npm run dev
```

Then:

```bash
curl http://localhost:4000/health
```
