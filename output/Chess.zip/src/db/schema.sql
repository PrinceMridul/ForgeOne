-- Schema for online-chess-called
-- Generated from the project blueprint.

create table if not exists boards (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  columnOrder text,
  created_at timestamptz not null default now()
);

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text,
  displayName text,
  avatarUrl text,
  created_at timestamptz not null default now()
);
