import Fastify from 'fastify';
import { WebSocketServer } from 'ws';
import { boardsRoutes } from './routes/boards';
import { usersRoutes } from './routes/users';

const app = Fastify({ logger: true });

async function main() {
  app.get('/health', async () => ({
    status: 'ok',
    service: 'online-chess-called',
    timestamp: new Date().toISOString(),
  }));

  await app.register(boardsRoutes, { prefix: '/api/boards' });
  await app.register(usersRoutes, { prefix: '/api/users' });

  // Realtime fan-out: one room per resource id, presence pings every 30s.
  const sockets = new Set<import('ws').WebSocket>();
  const wss = new WebSocketServer({ server: app.server, path: '/realtime' });
  wss.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('message', (raw) => {
      for (const peer of sockets) {
        if (peer !== socket && peer.readyState === peer.OPEN) peer.send(raw.toString());
      }
    });
    socket.on('close', () => sockets.delete(socket));
  });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen({ port, host: '0.0.0.0' });
  app.log.info(`online-chess-called listening on http://localhost:${port}`);
}

main().catch((err) => {
  app.log.error(err);
  process.exit(1);
});
