import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';

export const boardSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  columnOrder: z.string(),
  createdAt: z.string().datetime(),
});

export type Board = z.infer<typeof boardSchema>;

export const createBoardSchema = boardSchema.omit({ id: true, createdAt: true });

const store = new Map<string, Board>();

export const boardsRoutes: FastifyPluginAsync = async (app) => {
  app.get('/', async () => ({ data: Array.from(store.values()) }));

  app.get<{ Params: { id: string } }>('/:id', async (request, reply) => {
    const found = store.get(request.params.id);
    if (!found) return reply.status(404).send({ error: 'Board not found' });
    return { data: found };
  });

  app.post('/', async (request, reply) => {
    const parsed = createBoardSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Invalid payload', issues: parsed.error.issues });
    }
    const record: Board = {
      id: crypto.randomUUID(),
      ...parsed.data,
      createdAt: new Date().toISOString(),
    };
    store.set(record.id, record);
    return reply.status(201).send({ data: record });
  });

  app.delete<{ Params: { id: string } }>('/:id', async (request, reply) => {
    if (!store.delete(request.params.id)) {
      return reply.status(404).send({ error: 'Board not found' });
    }
    return reply.status(204).send();
  });
};
