import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { boardsRoutes } from '../src/routes/boards';

describe('boards routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(boardsRoutes, { prefix: '/boards' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/boards' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/boards', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a board', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/boards',
      payload: {
      name: 'example',
      columnOrder: 'example',
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/boards/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
