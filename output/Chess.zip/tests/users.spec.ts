import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { usersRoutes } from '../src/routes/users';

describe('users routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(usersRoutes, { prefix: '/users' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/users' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/users', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a user', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/users',
      payload: {
      email: 'example',
      displayName: 'example',
      avatarUrl: 'example',
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/users/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
