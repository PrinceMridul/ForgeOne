# Hospital Management Called

Build a hospital management platform called MediCore.

Requirements:

Modules:
- Patients
- Doctors
- Nurses
- Appointments
- Prescriptions
- Medical Records
- Pharmacy
- Billing
- Insurance
- Laboratory
- Radiology
- Emergency
- ICU
- Bed Management

Admin:
- Staff scheduling
- Audit logs
- Compliance
- Reporting

Tech:
- PostgreSQL
- Docker
- JWT
- HIPAA-ready architecture
- Production deployment
- CI/CD

## Capabilities

- **Billing & subscriptions** — Stripe webhooks reconciled against a local subscription ledger
- **Analytics & reporting** — Pre-aggregated rollup tables refreshed on write
- **Scheduling** — Cron-driven worker with timezone-aware recurrence rules

## API

| Route | Methods | Description |
|---|---|---|
| `/health` | `GET` | Liveness probe |
| `/api/subscriptions` | `GET` `POST` `DELETE` | Subscription resource |
| `/api/bookings` | `GET` `POST` `DELETE` | Booking resource |
| `/api/users` | `GET` `POST` `DELETE` | User resource |

## Data model

- **subscriptions** — plan, status, renewsAt
- **bookings** — startsAt, endsAt, status
- **users** — email, displayName, avatarUrl

## Quick start

```bash
npm install
npm run dev
```

Then:

```bash
curl http://localhost:4000/health
```
