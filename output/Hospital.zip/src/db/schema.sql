-- Schema for hospital-management-called
-- Generated from the project blueprint.

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  plan text,
  status text,
  renewsAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  startsAt timestamptz,
  endsAt timestamptz,
  status text,
  created_at timestamptz not null default now()
);

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text,
  displayName text,
  avatarUrl text,
  created_at timestamptz not null default now()
);
