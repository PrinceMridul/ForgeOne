import Fastify from 'fastify';
import { subscriptionsRoutes } from './routes/subscriptions';
import { bookingsRoutes } from './routes/bookings';
import { usersRoutes } from './routes/users';

const app = Fastify({ logger: true });

async function main() {
  app.get('/health', async () => ({
    status: 'ok',
    service: 'hospital-management-called',
    timestamp: new Date().toISOString(),
  }));

  await app.register(subscriptionsRoutes, { prefix: '/api/subscriptions' });
  await app.register(bookingsRoutes, { prefix: '/api/bookings' });
  await app.register(usersRoutes, { prefix: '/api/users' });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen({ port, host: '0.0.0.0' });
  app.log.info(`hospital-management-called listening on http://localhost:${port}`);
}

main().catch((err) => {
  app.log.error(err);
  process.exit(1);
});
