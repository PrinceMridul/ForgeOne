import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { bookingsRoutes } from '../src/routes/bookings';

describe('bookings routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(bookingsRoutes, { prefix: '/bookings' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/bookings' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/bookings', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a booking', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/bookings',
      payload: {
      startsAt: new Date().toISOString(),
      endsAt: new Date().toISOString(),
      status: 'example',
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/bookings/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
