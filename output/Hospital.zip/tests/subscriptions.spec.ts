import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { subscriptionsRoutes } from '../src/routes/subscriptions';

describe('subscriptions routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(subscriptionsRoutes, { prefix: '/subscriptions' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/subscriptions' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/subscriptions', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a subscription', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/subscriptions',
      payload: {
      plan: 'example',
      status: 'example',
      renewsAt: new Date().toISOString(),
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/subscriptions/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
