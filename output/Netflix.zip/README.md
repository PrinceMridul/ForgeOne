# ProductionReady NetflixInspired Streaming

Build a production-ready Netflix-inspired streaming platform called CineVerse.

Features:
- Authentication
- Movie browsing
- Search
- Categories
- Watchlist
- Recommendations
- User profiles
- Admin dashboard
- Stripe subscriptions
- PostgreSQL
- Docker
- CI/CD
- README
- Production-ready repository

## Capabilities

- **Authentication & tenancy** — Session-based auth with per-tenant row scoping
- **Billing & subscriptions** — Stripe webhooks reconciled against a local subscription ledger
- **Search** — Postgres full-text search with a GIN index and ranked results
- **Media & file storage** — S3-compatible object storage with presigned upload URLs
- **Analytics & reporting** — Pre-aggregated rollup tables refreshed on write
- **AI features** — Embedding pipeline backed by a vector index for semantic recall

## API

| Route | Methods | Description |
|---|---|---|
| `/health` | `GET` | Liveness probe |
| `/api/subscriptions` | `GET` `POST` `DELETE` | Subscription resource |
| `/api/dashboards` | `GET` `POST` `DELETE` | Dashboard resource |
| `/api/users` | `GET` `POST` `DELETE` | User resource |
| `/api/titles` | `GET` `POST` `DELETE` | Title resource |

## Data model

- **subscriptions** — plan, status, renewsAt
- **dashboards** — name, layout
- **users** — email, displayName, avatarUrl
- **titles** — name, synopsis, releaseYear

## Quick start

```bash
npm install
npm run dev
```

Then:

```bash
curl http://localhost:4000/health
```
