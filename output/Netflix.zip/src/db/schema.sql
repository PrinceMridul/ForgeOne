-- Schema for production-ready-netflix-inspired-streaming
-- Generated from the project blueprint.

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  plan text,
  status text,
  renewsAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists dashboards (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  layout text,
  created_at timestamptz not null default now()
);

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text,
  displayName text,
  avatarUrl text,
  created_at timestamptz not null default now()
);

create table if not exists titles (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  synopsis text,
  releaseYear integer,
  created_at timestamptz not null default now()
);

-- Full-text search over the primary text column of each resource.
create index if not exists subscriptions_search_idx on subscriptions using gin (to_tsvector('english', coalesce(plan::text, '')));
create index if not exists dashboards_search_idx on dashboards using gin (to_tsvector('english', coalesce(name::text, '')));
create index if not exists users_search_idx on users using gin (to_tsvector('english', coalesce(email::text, '')));
create index if not exists titles_search_idx on titles using gin (to_tsvector('english', coalesce(name::text, '')));
