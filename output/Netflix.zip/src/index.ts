import Fastify from 'fastify';
import { subscriptionsRoutes } from './routes/subscriptions';
import { dashboardsRoutes } from './routes/dashboards';
import { usersRoutes } from './routes/users';
import { titlesRoutes } from './routes/titles';

const app = Fastify({ logger: true });

async function main() {
  app.get('/health', async () => ({
    status: 'ok',
    service: 'production-ready-netflix-inspired-streaming',
    timestamp: new Date().toISOString(),
  }));

  await app.register(subscriptionsRoutes, { prefix: '/api/subscriptions' });
  await app.register(dashboardsRoutes, { prefix: '/api/dashboards' });
  await app.register(usersRoutes, { prefix: '/api/users' });
  await app.register(titlesRoutes, { prefix: '/api/titles' });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen({ port, host: '0.0.0.0' });
  app.log.info(`production-ready-netflix-inspired-streaming listening on http://localhost:${port}`);
}

main().catch((err) => {
  app.log.error(err);
  process.exit(1);
});
