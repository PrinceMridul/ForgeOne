import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';

export const titleSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  synopsis: z.string(),
  releaseYear: z.number().int(),
  createdAt: z.string().datetime(),
});

export type Title = z.infer<typeof titleSchema>;

export const createTitleSchema = titleSchema.omit({ id: true, createdAt: true });

const store = new Map<string, Title>();

export const titlesRoutes: FastifyPluginAsync = async (app) => {
  app.get('/', async () => ({ data: Array.from(store.values()) }));

  app.get<{ Params: { id: string } }>('/:id', async (request, reply) => {
    const found = store.get(request.params.id);
    if (!found) return reply.status(404).send({ error: 'Title not found' });
    return { data: found };
  });

  app.post('/', async (request, reply) => {
    const parsed = createTitleSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Invalid payload', issues: parsed.error.issues });
    }
    const record: Title = {
      id: crypto.randomUUID(),
      ...parsed.data,
      createdAt: new Date().toISOString(),
    };
    store.set(record.id, record);
    return reply.status(201).send({ data: record });
  });

  app.delete<{ Params: { id: string } }>('/:id', async (request, reply) => {
    if (!store.delete(request.params.id)) {
      return reply.status(404).send({ error: 'Title not found' });
    }
    return reply.status(204).send();
  });
};
