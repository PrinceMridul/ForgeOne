import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { dashboardsRoutes } from '../src/routes/dashboards';

describe('dashboards routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(dashboardsRoutes, { prefix: '/dashboards' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/dashboards' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/dashboards', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a dashboard', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/dashboards',
      payload: {
      name: 'example',
      layout: 'example',
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/dashboards/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
