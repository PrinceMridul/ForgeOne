# AI Research Collaboration

Build an AI research collaboration platform called ResearchHub AI.

Requirements:

Features:
- Projects
- Research papers
- Experiment tracking
- Dataset management
- Model registry
- Prompt versioning
- Notebook execution
- GPU job queue
- Team collaboration
- Paper summaries
- Citation graph
- Benchmark tracking
- LLM evaluation

Admin:
- Organization management
- Billing
- Analytics

Tech:
- Python
- FastAPI
- PostgreSQL
- Qdrant
- Redis
- Docker
- Kubernetes
- CI/CD

## Capabilities

- **Realtime collaboration** — WebSocket gateway with per-room fan-out and presence heartbeats
- **Billing & subscriptions** — Stripe webhooks reconciled against a local subscription ledger
- **Search** — Postgres full-text search with a GIN index and ranked results
- **Analytics & reporting** — Pre-aggregated rollup tables refreshed on write
- **AI features** — Embedding pipeline backed by a vector index for semantic recall

## API

| Route | Methods | Description |
|---|---|---|
| `/health` | `GET` | Liveness probe |
| `/api/projects` | `GET` `POST` `DELETE` | Project resource |
| `/api/subscriptions` | `GET` `POST` `DELETE` | Subscription resource |
| `/api/events` | `GET` `POST` `DELETE` | Event resource |
| `/api/workspaces` | `GET` `POST` `DELETE` | Workspace resource |

## Data model

- **projects** — name, slug, archived
- **subscriptions** — plan, status, renewsAt
- **events** — kind, payload, occurredAt
- **workspaces** — name, slug

## Quick start

```bash
npm install
npm run dev
```

Then:

```bash
curl http://localhost:4000/health
```
