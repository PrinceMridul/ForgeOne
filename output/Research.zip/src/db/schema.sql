-- Schema for ai-research-collaboration
-- Generated from the project blueprint.

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text,
  archived boolean,
  created_at timestamptz not null default now()
);

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  plan text,
  status text,
  renewsAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  kind text,
  payload text,
  occurredAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text,
  created_at timestamptz not null default now()
);

-- Full-text search over the primary text column of each resource.
create index if not exists projects_search_idx on projects using gin (to_tsvector('english', coalesce(name::text, '')));
create index if not exists subscriptions_search_idx on subscriptions using gin (to_tsvector('english', coalesce(plan::text, '')));
create index if not exists events_search_idx on events using gin (to_tsvector('english', coalesce(kind::text, '')));
create index if not exists workspaces_search_idx on workspaces using gin (to_tsvector('english', coalesce(name::text, '')));
