import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { projectsRoutes } from '../src/routes/projects';

describe('projects routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(projectsRoutes, { prefix: '/projects' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/projects' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/projects', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a project', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/projects',
      payload: {
      name: 'example',
      slug: 'example',
      archived: false,
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/projects/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
