# AI-powered Resume Builder

Build an AI-powered resume builder platform called ResumeForge.

Requirements:

Features:
- User authentication
- Resume editor
- Drag-and-drop sections
- AI resume suggestions
- ATS optimization
- Resume templates
- PDF export
- Cover letter generator
- Job tracker
- Portfolio builder
- Version history

Admin:
- Template management
- Subscription plans
- Usage analytics

Tech:
- PostgreSQL
- OpenAI API
- Stripe
- Docker
- CI/CD
- Production-ready README

## Capabilities

- **Authentication & tenancy** — Session-based auth with per-tenant row scoping
- **Billing & subscriptions** — Stripe webhooks reconciled against a local subscription ledger
- **Analytics & reporting** — Pre-aggregated rollup tables refreshed on write
- **AI features** — Embedding pipeline backed by a vector index for semantic recall

## API

| Route | Methods | Description |
|---|---|---|
| `/health` | `GET` | Liveness probe |
| `/api/projects` | `GET` `POST` `DELETE` | Project resource |
| `/api/subscriptions` | `GET` `POST` `DELETE` | Subscription resource |
| `/api/events` | `GET` `POST` `DELETE` | Event resource |
| `/api/users` | `GET` `POST` `DELETE` | User resource |

## Data model

- **projects** — name, slug, archived
- **subscriptions** — plan, status, renewsAt
- **events** — kind, payload, occurredAt
- **users** — email, displayName, avatarUrl

## Quick start

```bash
npm install
npm run dev
```

Then:

```bash
curl http://localhost:4000/health
```
