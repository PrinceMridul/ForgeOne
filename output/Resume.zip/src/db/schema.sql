-- Schema for ai-powered-resume-builder
-- Generated from the project blueprint.

create table if not exists projects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text,
  archived boolean,
  created_at timestamptz not null default now()
);

create table if not exists subscriptions (
  id uuid primary key default gen_random_uuid(),
  plan text,
  status text,
  renewsAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  kind text,
  payload text,
  occurredAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text,
  displayName text,
  avatarUrl text,
  created_at timestamptz not null default now()
);
