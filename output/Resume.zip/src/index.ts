import Fastify from 'fastify';
import { projectsRoutes } from './routes/projects';
import { subscriptionsRoutes } from './routes/subscriptions';
import { eventsRoutes } from './routes/events';
import { usersRoutes } from './routes/users';

const app = Fastify({ logger: true });

async function main() {
  app.get('/health', async () => ({
    status: 'ok',
    service: 'ai-powered-resume-builder',
    timestamp: new Date().toISOString(),
  }));

  await app.register(projectsRoutes, { prefix: '/api/projects' });
  await app.register(subscriptionsRoutes, { prefix: '/api/subscriptions' });
  await app.register(eventsRoutes, { prefix: '/api/events' });
  await app.register(usersRoutes, { prefix: '/api/users' });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen({ port, host: '0.0.0.0' });
  app.log.info(`ai-powered-resume-builder listening on http://localhost:${port}`);
}

main().catch((err) => {
  app.log.error(err);
  process.exit(1);
});
