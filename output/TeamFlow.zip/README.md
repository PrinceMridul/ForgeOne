# ProductionReady Team Collaboration

Build a production-ready team collaboration platform called TeamFlow.

Requirements:

Features:
- Organizations
- Workspaces
- Channels
- Threads
- Direct Messages
- Presence indicators
- Typing indicators
- File uploads
- Emoji reactions
- Message search
- Notifications
- Voice rooms
- Video meetings

Admin Features:
- User management
- Workspace analytics
- Audit logs
- Invite management

Technical Requirements:
- WebSockets
- PostgreSQL
- Redis
- Docker
- JWT authentication
- Object storage
- Production-ready deployment
- README
- CI/CD

## Capabilities

- **Realtime collaboration** — WebSocket gateway with per-room fan-out and presence heartbeats
- **Authentication & tenancy** — Session-based auth with per-tenant row scoping
- **Search** — Postgres full-text search with a GIN index and ranked results
- **Media & file storage** — S3-compatible object storage with presigned upload URLs
- **Notifications** — Queue-backed delivery with retry and idempotency keys
- **Analytics & reporting** — Pre-aggregated rollup tables refreshed on write

## API

| Route | Methods | Description |
|---|---|---|
| `/health` | `GET` | Liveness probe |
| `/api/channels` | `GET` `POST` `DELETE` | Channel resource |
| `/api/threads` | `GET` `POST` `DELETE` | Thread resource |
| `/api/messages` | `GET` `POST` `DELETE` | Message resource |
| `/api/rooms` | `GET` `POST` `DELETE` | Room resource |

## Data model

- **channels** — name, topic, isPrivate
- **threads** — parentId, title, replyCount
- **messages** — body, authorId, sentAt
- **rooms** — name, startedAt, participantCount

## Quick start

```bash
npm install
npm run dev
```

Then:

```bash
curl http://localhost:4000/health
```
