-- Schema for production-ready-team-collaboration
-- Generated from the project blueprint.

create table if not exists channels (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  topic text,
  isPrivate boolean,
  created_at timestamptz not null default now()
);

create table if not exists threads (
  id uuid primary key default gen_random_uuid(),
  parentId uuid,
  title text,
  replyCount integer,
  created_at timestamptz not null default now()
);

create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  body text,
  authorId uuid,
  sentAt timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists rooms (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  startedAt timestamptz,
  participantCount integer,
  created_at timestamptz not null default now()
);

-- Full-text search over the primary text column of each resource.
create index if not exists channels_search_idx on channels using gin (to_tsvector('english', coalesce(name::text, '')));
create index if not exists threads_search_idx on threads using gin (to_tsvector('english', coalesce(parentId::text, '')));
create index if not exists messages_search_idx on messages using gin (to_tsvector('english', coalesce(body::text, '')));
create index if not exists rooms_search_idx on rooms using gin (to_tsvector('english', coalesce(name::text, '')));
