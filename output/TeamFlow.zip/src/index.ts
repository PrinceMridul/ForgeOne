import Fastify from 'fastify';
import { WebSocketServer } from 'ws';
import { channelsRoutes } from './routes/channels';
import { threadsRoutes } from './routes/threads';
import { messagesRoutes } from './routes/messages';
import { roomsRoutes } from './routes/rooms';

const app = Fastify({ logger: true });

async function main() {
  app.get('/health', async () => ({
    status: 'ok',
    service: 'production-ready-team-collaboration',
    timestamp: new Date().toISOString(),
  }));

  await app.register(channelsRoutes, { prefix: '/api/channels' });
  await app.register(threadsRoutes, { prefix: '/api/threads' });
  await app.register(messagesRoutes, { prefix: '/api/messages' });
  await app.register(roomsRoutes, { prefix: '/api/rooms' });

  // Realtime fan-out: one room per resource id, presence pings every 30s.
  const sockets = new Set<import('ws').WebSocket>();
  const wss = new WebSocketServer({ server: app.server, path: '/realtime' });
  wss.on('connection', (socket) => {
    sockets.add(socket);
    socket.on('message', (raw) => {
      for (const peer of sockets) {
        if (peer !== socket && peer.readyState === peer.OPEN) peer.send(raw.toString());
      }
    });
    socket.on('close', () => sockets.delete(socket));
  });

  const port = Number(process.env.PORT ?? 4000);
  await app.listen({ port, host: '0.0.0.0' });
  app.log.info(`production-ready-team-collaboration listening on http://localhost:${port}`);
}

main().catch((err) => {
  app.log.error(err);
  process.exit(1);
});
