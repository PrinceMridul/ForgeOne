import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';

export const roomSchema = z.object({
  id: z.string().uuid(),
  name: z.string(),
  startedAt: z.string().datetime(),
  participantCount: z.number().int(),
  createdAt: z.string().datetime(),
});

export type Room = z.infer<typeof roomSchema>;

export const createRoomSchema = roomSchema.omit({ id: true, createdAt: true });

const store = new Map<string, Room>();

export const roomsRoutes: FastifyPluginAsync = async (app) => {
  app.get('/', async () => ({ data: Array.from(store.values()) }));

  app.get<{ Params: { id: string } }>('/:id', async (request, reply) => {
    const found = store.get(request.params.id);
    if (!found) return reply.status(404).send({ error: 'Room not found' });
    return { data: found };
  });

  app.post('/', async (request, reply) => {
    const parsed = createRoomSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Invalid payload', issues: parsed.error.issues });
    }
    const record: Room = {
      id: crypto.randomUUID(),
      ...parsed.data,
      createdAt: new Date().toISOString(),
    };
    store.set(record.id, record);
    return reply.status(201).send({ data: record });
  });

  app.delete<{ Params: { id: string } }>('/:id', async (request, reply) => {
    if (!store.delete(request.params.id)) {
      return reply.status(404).send({ error: 'Room not found' });
    }
    return reply.status(204).send();
  });
};
