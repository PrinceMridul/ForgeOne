import type { FastifyPluginAsync } from 'fastify';
import { z } from 'zod';

export const threadSchema = z.object({
  id: z.string().uuid(),
  parentId: z.string().uuid(),
  title: z.string(),
  replyCount: z.number().int(),
  createdAt: z.string().datetime(),
});

export type Thread = z.infer<typeof threadSchema>;

export const createThreadSchema = threadSchema.omit({ id: true, createdAt: true });

const store = new Map<string, Thread>();

export const threadsRoutes: FastifyPluginAsync = async (app) => {
  app.get('/', async () => ({ data: Array.from(store.values()) }));

  app.get<{ Params: { id: string } }>('/:id', async (request, reply) => {
    const found = store.get(request.params.id);
    if (!found) return reply.status(404).send({ error: 'Thread not found' });
    return { data: found };
  });

  app.post('/', async (request, reply) => {
    const parsed = createThreadSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Invalid payload', issues: parsed.error.issues });
    }
    const record: Thread = {
      id: crypto.randomUUID(),
      ...parsed.data,
      createdAt: new Date().toISOString(),
    };
    store.set(record.id, record);
    return reply.status(201).send({ data: record });
  });

  app.delete<{ Params: { id: string } }>('/:id', async (request, reply) => {
    if (!store.delete(request.params.id)) {
      return reply.status(404).send({ error: 'Thread not found' });
    }
    return reply.status(204).send();
  });
};
