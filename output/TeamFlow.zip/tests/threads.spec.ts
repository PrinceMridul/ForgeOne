import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import Fastify from 'fastify';
import type { FastifyInstance } from 'fastify';
import { threadsRoutes } from '../src/routes/threads';

describe('threads routes', () => {
  let app: FastifyInstance;

  beforeAll(async () => {
    app = Fastify();
    await app.register(threadsRoutes, { prefix: '/threads' });
    await app.ready();
  });

  afterAll(async () => {
    await app.close();
  });

  it('starts empty', async () => {
    const res = await app.inject({ method: 'GET', url: '/threads' });
    expect(res.statusCode).toBe(200);
    expect(JSON.parse(res.body).data).toEqual([]);
  });

  it('rejects an invalid payload', async () => {
    const res = await app.inject({ method: 'POST', url: '/threads', payload: {} });
    expect(res.statusCode).toBe(400);
  });

  it('creates and reads back a thread', async () => {
    const created = await app.inject({
      method: 'POST',
      url: '/threads',
      payload: {
      parentId: crypto.randomUUID(),
      title: 'example',
      replyCount: 1,
    },
    });
    expect(created.statusCode).toBe(201);

    const id = JSON.parse(created.body).data.id;
    const fetched = await app.inject({ method: 'GET', url: `/threads/${id}` });
    expect(fetched.statusCode).toBe(200);
  });
});
